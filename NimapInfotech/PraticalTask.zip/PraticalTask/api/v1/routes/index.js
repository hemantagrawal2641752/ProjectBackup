const express = require('express');
const router = express.Router();
const driverController = require('../controllers/driver');

router.post('/driver/register', driverController.registerDriver);
router.post('/driver/sendLocation', driverController.sendLocation);
router.post('/driver/avaliable_cabs', driverController.avaliableCabs);

module.exports = router;
