const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const app = express();
const db = require('./DB/connection');
const globalErrorHandler = require('./utils/errorController');

//require routes
const initAPISVersions = require('./api');

//define body paresr
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: false, limit: '50mb', extended: true, parameterLimit: 50000 }));


//using routes
initAPISVersions(app,'')

app.all('*', (req, res, next) => {
  res.status(404).json({
    status: false,
    message: 'Requested API not found',
  });
});

const testConnection = async () => {
  try {
    await db.authenticate();
    console.log('mysql connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the mysql database:', error);
  }
};

testConnection();
app.use(globalErrorHandler);

app.listen(process.env.PORT, () => {
  console.log('testing server is running.....');
});
